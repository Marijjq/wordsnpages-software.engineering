@extends('admin.layouts.master')

@section('content')
    <section class="section">
        <div class="section-header">
            <h1>All Books</h1>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <a href="{{route('admin.books.create')}}" class="btn btn-primary">Create New</a>
                            <form class="form-inline">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped table-md">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Genre</th>
                                        <th>Publishing Year</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Updated At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($books as $book)
                                        <tr>
                                            <td>{{ $book->ISBN }}</td>
                                            <td> <img src="{{ asset($book->image) }}" alt="" width="80"> </td>
                                            <td>{{ $book->title }}</td>
                                            <td>{{ optional($book->author)->name . ' ' . optional($book->author)->surname }}</td>
                                            <td>{{ optional($book->category)->name }}</td>
                                            <td>{{ $book->publishing_year }}</td>
                                            <td>${{ $book->init_price }}</td>
                                            <td>{{ $book->quantity }}</td>
                                            <td>
                                                <select class="form-control" 
                                                        onchange="changeStatus('{{ route('admin.books.changeStatus', $book->ISBN) }}', this.value)">
                                                    <option value="available" {{ $book->status === 'available' ? 'selected' : '' }}>Available</option>
                                                    <option value="unavailable" {{ $book->status === 'unavailable' ? 'selected' : '' }}>Unavailable</option>
                                                </select>
                                            </td>
                                            <td>{{ $book->created_at->format('Y-m-d H:i:s') }}</td>
                                            <td>{{ $book->updated_at->format('Y-m-d H:i:s') }}</td>
                                            <td>
                                                <a href="{{ route('admin.books.show', $book->ISBN) }}" class="btn btn-info">Show</a>
                                                <a href="{{ route('admin.books.edit', $book->ISBN) }}" class="btn btn-primary">Edit</a>
                                                <form action="{{ route('admin.books.destroy', $book->ISBN) }}" method="POST"
                                                    style="display: inline;">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger"
                                                        onclick="return confirm('Are you sure?')">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

<script>
    function changeStatus(route, status) {
        fetch(route, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            },
            body: JSON.stringify({ status: status }),
        })
        .then(response => response.json())
        .then(data => {
            // Handle any additional logic if needed
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
</script>
