
@extends('admin.layouts.master')

@section('content')

<section class="section">
  <div class="section-header">
    <h1>Create New Categories</h1>
  </div>
  @if ($errors->any())
  @foreach ($errors->all() as $error )
      <span class="alert alert-danger">{{$error}}</span>
  @endforeach 
@endif
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card-header">
        Category Details
    </div>
      <div class="card-body">
         <form action="{{ route('admin.categories.store') }}" method="POST">
        @csrf
            <div class="mb-3">
              <label for="name" class="form-label">Name:</label>
              <input type="text" name="name" class="form-control" style="width: 100%" required>
            </div>

            <button type="submit" class="btn btn-primary">Create Category</button>
        </form>
      </div>
    </div>
  </div>
</section>

@endsection
