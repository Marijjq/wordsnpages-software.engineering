@extends('admin.layouts.master')

@section('content')

<section class="section">
  <div class="section-header">
    <h1>Show Category</h1>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-8">

      <h3>{{ $category->name }}</h3>

      <p><strong>ID:</strong> {{ $category->categoryId }}</p>
      <p><strong>Name:</strong> {{ $category->name }}</p>
      <p><strong>Created At:</strong> {{ $category->created_at->format('Y-m-d H:i:s') }}</p>
      <p><strong>Updated At:</strong> {{ $category->updated_at->format('Y-m-d H:i:s') }}</p>

      <div class="mt-3">
        <a href="{{ route('admin.categories.edit', $category->categoryId) }}" class="btn btn-warning">Edit Category</a>
        <form action="{{ route('admin.categories.destroy', $category->categoryId) }}" method="POST" style="display: inline;">
          @csrf
          @method('DELETE')
          <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete Category</button>
        </form>
      </div>

    </div>
  </div>
</section>

@endsection
