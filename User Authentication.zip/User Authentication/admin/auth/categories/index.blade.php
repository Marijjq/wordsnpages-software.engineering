@extends('admin.layouts.master')

@section('content')
    <section class="section">
        <div class="section-header">
            <h1>All Books</h1>
        </div>

        <div class="row">
            <div class="col-12 ">
                <div class="card">
                    <div class="card-header">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <a href="{{route('admin.categories.create')}}" class="btn btn-primary">Create New</a>
                            <form class="form-inline">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div> 
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped table-md">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Created At</th>
                                        <th>Updated At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($categories as $category)
                                        <tr>
                                            <td>{{ $category->categoryId }}</td>
                                            <td>{{ $category->name }}</td>
                                            <td>
                                                @if ($category->created_at instanceof \Illuminate\Support\Carbon)
                                                    {{ $category->created_at->format('Y-m-d H:i:s') }}
                                                @else
                                                    {{ $category->created_at }}
                                                @endif
                                            </td>
                                            <td>
                                                @if ($category->updated_at instanceof \Illuminate\Support\Carbon)
                                                    {{ $category->updated_at->format('Y-m-d H:i:s') }}
                                                @else
                                                    {{ $category->updated_at }}
                                                @endif
                                            </td>
                                            <td>
                                                <a href="{{ route('admin.categories.show', $category->categoryId) }}" class="btn btn-info">View</a>
                                                <a href="{{ route('admin.categories.edit', $category->categoryId) }}" class="btn btn-warning">Edit</a>
                                                <form action="{{ route('admin.categories.destroy', $category->categoryId) }}" method="POST" style="display: inline;">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex">
                            {{ $categories->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

