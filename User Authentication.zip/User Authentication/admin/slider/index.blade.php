@extends('admin.layouts.master')

@section('content')
    <section class="section">
        <div class="section-header">
            <h1>All Sliders</h1>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <a href="{{route('admin.slider.create')}}" class="btn btn-primary">Create New</a>
                            <form class="form-inline">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>   
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped table-md">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Banner</th>
                                        <th>Type</th>
                                        <th>Title</th>
                                        <th>Starting Price</th>
                                        <th>URL</th>
                                        <th>Serial</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($sliders as $slider)
                                        <tr>
                                            <td>{{ $slider->id }}</td>
                                            <td>
                                                <img src="{{ asset($slider->banner) }}" alt="Slider Banner" class="img-fluid">
                                            </td>
                                            <td>{{ $slider->type }}</td>
                                            <td>{{ $slider->title }}</td>
                                            <td>{{ $slider->starting_price }}</td>
                                            <td>{{$slider->btn_url}}</td>
                                            <td>{{$slider->serial}}</td>
                                            <td>{{$slider->status}}</td>
                                            <td>
                                                <a href="{{ route('admin.slider.show', $slider->id) }}"
                                                    class="btn btn-info">Show</a>
                                                <a href="{{ route('admin.slider.edit', $slider->id) }}"
                                                    class="btn btn-primary">Edit</a>
                                                <form action="{{ route('admin.slider.destroy',$slider->id) }}"
                                                    method="POST" style="display: inline;">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger"
                                                        onclick="return confirm('Are you sure?')">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
